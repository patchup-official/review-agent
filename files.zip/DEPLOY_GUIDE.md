# 🚀 Deploy ReviewAgent su Render.com

## File inclusi
- `review_agent.py` — script principale
- `requirements.txt` — dipendenze Python
- `render.yaml` — configurazione Render (cron job)

---

## STEP 1 — Carica su GitHub

1. Crea un repo GitHub (es. `review-agent`)
2. Carica i 3 file nella root del repo
3. Push

---

## STEP 2 — Crea il Cron Job su Render

1. Vai su **render.com** → Dashboard
2. Clicca **"New +"** → **"Cron Job"**
3. Collega il tuo repo GitHub
4. Render rileva automaticamente il `render.yaml`

Oppure manualmente:
- **Runtime:** Python 3
- **Build Command:** `pip install -r requirements.txt`
- **Start Command:** `python review_agent.py`
- **Schedule:** `0 * * * *` (ogni ora)

---

## STEP 3 — Variabili d'ambiente

Nella dashboard Render → **Environment** → aggiungi:

| Variabile | Valore |
|---|---|
| `ANTHROPIC_API_KEY` | La tua chiave da console.anthropic.com |
| `GOOGLE_LOCATION_ID` | es. `locations/123456789` |
| `GOOGLE_CREDENTIALS_JSON` | Il contenuto intero del file credentials.json |
| `ALERT_EMAIL_TO` | La tua email iPhone (es. tu@gmail.com) |
| `SMTP_USER` | Email Gmail mittente |
| `SMTP_PASSWORD` | App Password Gmail (non la password normale!) |

---

## STEP 4 — App Password Gmail

Per `SMTP_PASSWORD` devi usare una App Password:
1. Vai su myaccount.google.com → Sicurezza
2. Attiva **Verifica in 2 passaggi** (se non attiva)
3. Cerca **"Password per le app"**
4. Crea una password per "Mail" → copia i 16 caratteri

---

## STEP 5 — Credenziali Google Business API

1. Vai su console.cloud.google.com
2. Crea progetto → abilita **"My Business API"**
3. Crea **Service Account** → scarica `credentials.json`
4. Vai su Google Business Profile → Impostazioni →
   aggiungi l'email del service account come manager

---

## ✅ Verifica

Nella dashboard Render puoi:
- Vedere i log di ogni esecuzione
- Eseguire manualmente con "Run Now"
- Ricevere notifiche email se il job fallisce

---

## 📱 Sul tuo iPhone

Gli alert arriveranno direttamente via email.
Attiva le notifiche push per Gmail/Mail su iPhone
e riceverai un ping ogni volta che arriva una recensione negativa.

---

## Schedulazione personalizzata

Modifica `schedule` in `render.yaml`:
- `0 * * * *`    → ogni ora
- `0 9 * * *`    → ogni giorno alle 9:00
- `0 9,18 * * *` → due volte al giorno (9:00 e 18:00)
- `*/30 * * * *` → ogni 30 minuti
